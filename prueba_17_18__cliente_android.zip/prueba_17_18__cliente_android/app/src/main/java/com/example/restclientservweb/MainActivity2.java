package com.example.restclientservweb;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import com.example.restclientservweb.Track;
import com.example.restclientservweb.TrackApiService;

public class MainActivity2 extends AppCompatActivity {

    TextView resultsTextView;
    EditText titleEditText, singerEditText;
    TrackApiService tracksApiService;
    String trackId;
    String trackTitle;
    String trackSinger;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);

        resultsTextView = findViewById(R.id.textView);
        titleEditText = findViewById(R.id.titleEditText);
        singerEditText = findViewById(R.id.singerEditText);
        Button vuelve = findViewById(R.id.vuelve);
        Button updateTrackButton = findViewById(R.id.updateTrackButton);
        Button deleteTrackButton = findViewById(R.id.deleteTrackButton);



        Intent intent = getIntent();
        trackId = intent.getStringExtra("track_id");
        trackTitle = intent.getStringExtra("track_title");
        trackSinger = intent.getStringExtra("track_singer");

        if (trackId != null && trackTitle != null && trackSinger != null) {
            resultsTextView.setText("ID: " + trackId + "\nTitle: " + trackTitle + "\nSinger: " + trackSinger);
            titleEditText.setText(trackTitle);
            singerEditText.setText(trackSinger);
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        vuelve.setOnClickListener(v -> {
            Intent i = new Intent(MainActivity2.this, MainActivity.class);
            startActivity(i);
        });

        updateTrackButton.setOnClickListener(v -> updateTrack());
        deleteTrackButton.setOnClickListener(v -> deleteTrack());
    }

    private void updateTrack() {
        String updatedTitle = titleEditText.getText().toString();
        String updatedSinger = singerEditText.getText().toString();
        Track updatedTrack = new Track(trackId, updatedTitle, updatedSinger);
        Call<Track> call = tracksApiService.updateTrack(trackId, updatedTrack);

        call.enqueue(new Callback<Track>() {
            @Override
            public void onResponse(Call<Track> call, Response<Track> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(MainActivity2.this, "Track updated successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity2.this, "Update failed", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Track> call, Throwable t) {
                Toast.makeText(MainActivity2.this, "Error: " + t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void deleteTrack() {
        Call<Void> call = tracksApiService.deleteTrack(trackId);
        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(MainActivity2.this, "Track deleted successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity2.this, "Failed to delete track", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Toast.makeText(MainActivity2.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}